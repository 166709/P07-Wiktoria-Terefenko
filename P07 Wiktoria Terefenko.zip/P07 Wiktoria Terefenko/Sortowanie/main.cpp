#include <iostream>
#include <time.h>
#include <fstream>
#include <cstdlib>
#include <algorithm>
#include <windows.h>
#include <iomanip>

using namespace std;
clock_t start,stop;
double czas;

void SortowanieBabelkowe(int tab[], int wielkosc_tab)
{
        for(int j=wielkosc_tab-1; j>1; j--)
            for(int i=0; i<j; i++)
                if(tab[i]>tab[i+1])
                swap(tab[i],tab[i+1]);
}

void SortowanieKopcowe(int tab[], int wielkosc_tab)
{
    int i,j,k,m,x;

        ///BUDUJEMY KOPIEC

    for(i = 2; i <= wielkosc_tab; i++)
    {
            j = i;
            k = j / 2;
            x = tab[i];
        while((k > 0) && (tab[k] < x))
        {
            tab[j] = tab[k];
            j = k; k = j / 2;
        }
        tab[j] = x;
    }

        ///ROZBIERAMY KOPIEC

    for(i = wielkosc_tab; i > 1; i--)
    {
            swap(tab[1], tab[i]);
            j = 1;
            k = 2;
        while(k < i)
        {
            if((k + 1 < i) && (tab[k + 1] > tab[k]))
                m = k + 1;
            else
                m = k;

            if(tab[m] <= tab[j]) break;
            swap(tab[j], tab[m]);
                j = m;
                k = j + j;
        }
    }
}



int main()
{
    int numer;
    int wielkosc_tab=30000;
    int tab[wielkosc_tab];
    fstream plik;
    plik.open("wynik.txt",ios::out);            ///utworzenie pliku wynikowego

    //cout<<"Wielkosc tablicy: ";               ///wpisywanie wielkosci tablicy
    //cin>>wielkosc_tab;

    cout<<"Sortowanie tablicy"<<endl<<endl;     ///poczatek do instrukcji switch
    cout<<"1. Sortowanie babelkowe"<<endl;
    cout<<"2. Sortowanie kopcowe"<<endl<<endl;
    cout<<"Prosze wybrac sposob sortowania: ";
    cin>>numer;

                       ///do celow testowych

    srand(time(NULL));

    plik<<"Wylosowana tablica: "<<endl;         ///losowanie i wyswietlanie tablicy ktora ma byc posortowana
    plik<<"[ ";                                 ///oraz zapisywanie jej do pliku wynik.txt
        for (int i=1; i<wielkosc_tab; i++)
    {
        tab[i]=rand()%1;
        plik<<tab[i]<<", ";
    }
    plik<<" ]"<<endl<<endl;




    switch(numer)                               ///wybor jednego z algorytmow sortujacych
    {
    case 1:
        {
    ///sortowanie babelkowe

    start=clock();                              ///rozpoczecie mierzenia czasu
    SortowanieBabelkowe(tab,wielkosc_tab);      ///sortowanie
    stop=clock();                               ///zatrzymanie czasu

    plik<<"Posortowana tablica: "<<endl;        ///zapis posortowanej tablicy
    plik<<"[ ";
    for(int i=0; i<wielkosc_tab-1; i++)
    {
        plik<<tab[i]<<", ";
    }
    plik<<" ]"<<endl;

    czas=(double)(stop-start)/CLOCKS_PER_SEC;   ///wyliczenie czasu sortowania
    cout<<"Czas sortowania babelkowego: "<<czas<<" s"<<endl;
    break;
        }



    case 2:
        {
    ///sortowanie kopcowe

    start=clock();
    SortowanieKopcowe(tab,wielkosc_tab);
    stop=clock();

    plik<<"Posortowana tablica: "<<endl;
    plik<<"[ ";
    for(int i=1; i<=wielkosc_tab-1; i++)
    {
        plik<<tab[i]<<", ";
    }
    plik<<" ]"<<endl;

    czas=(double)(stop-start)/CLOCKS_PER_SEC;
    cout<<"Czas sortowania kopcowego: "<<czas<<" s"<<endl;
    break;
        }
    }
    plik.close();
}
